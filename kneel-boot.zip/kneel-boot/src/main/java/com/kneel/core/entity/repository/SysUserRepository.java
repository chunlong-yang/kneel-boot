package com.kneel.core.entity.repository;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.kneel.core.entity.SysUser;

@Transactional
public interface SysUserRepository extends JpaRepository<SysUser, Long> {
 
	SysUser findByName(String name);
}
