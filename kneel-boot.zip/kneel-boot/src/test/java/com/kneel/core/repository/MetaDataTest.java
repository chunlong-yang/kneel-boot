package com.kneel.core.repository;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;

import javax.sql.DataSource;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.kneel.core.BaseApplicationTest;

public class MetaDataTest extends BaseApplicationTest {

	@Autowired
	private DataSource datasource;
	
	@Test
	public void testMetadate() throws SQLException{
		
		String tv = "sys_rpt_reportconfig";
		
		Connection conn = datasource.getConnection();
		Statement stmt = conn.createStatement();
		ResultSet rs=stmt.executeQuery("select * from " + tv + " where 1!=1");
		ResultSetMetaData rsmd = rs.getMetaData();
		int cc = rsmd.getColumnCount();
		for (int i = 1; i <= cc; i++) {
			int    type = rsmd.getColumnType(i);
			String name = rsmd.getColumnName(i); 
			System.out.println("normal: "+type+" - "+name);
			
			String javaType = convertToJava(type);
			String sqlType = convertToSql(javaType);
			System.out.println("type: "+javaType+" - "+sqlType);
		}
	}

	/**
	 * 常用的数据库类型转化为Java类型.
	 * 
	 * @param type
	 * @return
	 */
	private String convertToJava(int type) {
		switch(type){
			case Types.CHAR: 
			case Types.VARCHAR: 	
			case Types.LONGVARCHAR: 	
				return "String";
			case Types.NUMERIC:
				return "Long";
			case Types.DECIMAL:
				return "BigDecimal";
			case Types.BIT:
				return "Boolean";
			case Types.TINYINT:
				return "Byte";
			case Types.SMALLINT:
				return "Short";
			case Types.INTEGER:
				return "Integer";
			case Types.BIGINT:
				return "Long";
			case Types.FLOAT:
			case Types.DOUBLE:
				return "Double";
			case Types.BINARY:
			case Types.VARBINARY:
			case Types.LONGVARBINARY:
				return "Byte[]";
			case Types.DATE:
			case Types.TIME:
			case Types.TIMESTAMP:
				return "Date"; 
			default: throw new RuntimeException("Not Support Type("+type+")");
		} 
	}
	
	/**
	 * 常用的Java类型转化为数据库类型.
	 * 
	 * @param type
	 * @return
	 */
	private String convertToSql(String type) {
		switch(type){
			case "String":  
				return "VARCHAR";
			case "BigDecimal":
				return "DECIMAL";
			case "Boolean":
				return "BIT";
			case "Byte":
				return "TINYINT";
			case "Short":
				return "SMALLINT";
			case "Integer":
				return "INTEGER";
			case "Long":
				return "BIGINT";
			case "Double":
				return "DOUBLE";
			case "Byte[]":
				return "BINARY";
			case "Date": 
				return "DATE"; 
			default: throw new RuntimeException("Not Support Type("+type+")");
		} 
	}
}
