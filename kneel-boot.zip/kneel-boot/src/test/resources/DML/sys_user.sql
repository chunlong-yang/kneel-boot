insert into sys_user(id,name,password,active) values(sys_userseq.nextval,'admin','admin','Y');
insert into sys_user(id,name,password,active) values(sys_userseq.nextval,'user','user','Y');
insert into sys_user(id,name,password,active) values(sys_userseq.nextval,'seller','seller','Y');