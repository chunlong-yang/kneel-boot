insert into sys_privilege(id,name) values(sys_privilegeseq.nextval,'ADMIN_MENU_VIEW');
insert into sys_privilege(id,name) values(sys_privilegeseq.nextval,'USER_MENU_VIEW');
insert into sys_privilege(id,name) values(sys_privilegeseq.nextval,'USER_PAGE_WRITE');
insert into sys_privilege(id,name) values(sys_privilegeseq.nextval,'USER_PAGE_BUTTON');