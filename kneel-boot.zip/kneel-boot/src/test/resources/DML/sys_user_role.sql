insert into sys_user_role(id,user_id,role_id) values(sys_user_roleseq.nextval,1,1);
insert into sys_user_role(id,user_id,role_id) values(sys_user_roleseq.nextval,2,2);
insert into sys_user_role(id,user_id,role_id) values(sys_user_roleseq.nextval,3,3);