
INSERT INTO sys_properties(id,PROPERTY,VALUE,ENV,PROPCATEGORY,OVERRIDE,PRIORITY)VALUES(sys_propertiesseq.nextval,'log4j.rootLogger','ERROR, ROOT','DEV1','log4j','default',0);
INSERT INTO sys_properties(id,PROPERTY,VALUE,ENV,PROPCATEGORY,OVERRIDE,PRIORITY)VALUES(sys_propertiesseq.nextval,'maxThreads','101','DEV1','archive','default',0);