INSERT INTO sys_codelookup(CODETYPE,DECODE,ACTIVE,id) VALUES('Exception Type','Qty','Y',1);
INSERT INTO sys_codelookup(CODETYPE,DECODE,ACTIVE,id) VALUES('Exception Type','Price','Y',2);
INSERT INTO sys_codelookup(CODETYPE,DECODE,ACTIVE,id) VALUES('Exception Type','Cash','Y',3);
INSERT INTO sys_codelookup(CODETYPE,DECODE,ACTIVE,id) VALUES('Exception Type','Accrual','Y',4);
INSERT INTO sys_codelookup(CODETYPE,DECODE,ACTIVE,id) VALUES('Exception Type','Sec MV','Y',5);