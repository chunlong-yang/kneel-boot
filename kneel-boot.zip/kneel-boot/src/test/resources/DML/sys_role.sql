insert into sys_role(id,name) values(sys_roleseq.nextval,'ROLE_ADMIN');
insert into sys_role(id,name) values(sys_roleseq.nextval,'ROLE_USER');
insert into sys_role(id,name) values(sys_roleseq.nextval,'ROLE_SELLER');